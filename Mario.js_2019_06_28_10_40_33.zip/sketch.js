var mario;
var welkScherm = 0;
var xPos2;
var vijand;
var vijanden = [];
var aantalVijanden = 1;
var xPos;
var yPos;
var radius;
var speed;
var aantalVijand;
var img;
var achtergrond;
var cirkel;
var cirkel2;
var score;

function setup() {
  createCanvas(window.innerWidth, window.innerHeight-4);
  achtergrond = loadImage('https://cdn.glitch.com/a038604a-054c-4202-bb79-613e147864f4%2Fbos-spel-achtergrond-eps-vector_csp39754442.jpg?v=1560763798097');
  img = loadImage('https://cdn.glitch.com/a038604a-054c-4202-bb79-613e147864f4%2Fplayer.png?1559036293233');
  xPos = 50;
  yPos = window.innerHeight-72;
  console.log(xPos2)
  radius = 32;
  speed = 1.5;
  mario = new Mario(0, 0, radius, xPos, yPos, speed, 0, 0.2);
  for (var i = 0; i < aantalVijanden; i++){
    xPos2 = random(window.innerWidth-200, window.innerWidth);
    vijand = new Vijand(xPos2, yPos+30, 12, 1); 
    vijanden.push(vijand); 
  }
  //vijand = new Vijand(xPos2, yPos+30, 12, 1);
  score = 0;
}

function draw() {
    if (welkScherm == 0) {
    startScherm();
  } else if (welkScherm == 1) {
    gameScherm();
  } else if (welkScherm == 2) {
    gameOverScherm();
  }
  //background(220);
  //line(0, 421+12, window.innerWidth, 421+12);
 // line(0, 411+12, window.innerWidth, 411+12);
 // mario.display();
  //mario.move();
}

function startScherm(){
  background(220);
  fill(0, 255, 0);
  textSize(32);
  textAlign(CENTER);
  text("Klik om te starten", height/3, width/3);
}

function gameScherm() {
  background(achtergrond);
  line(0, window.innerHeight-25, window.innerWidth, window.innerHeight-25);
  line(0, window.innerHeight-15, window.innerWidth, window.innerHeight-15);
  mario.display();
  mario.move();
  //aantalVijand = 10;
  //for (var i = 0; i < aantalVijand.length; i++){
    //vijand = aantalVijand[i];
    //vijand.display();
    //vijand.move();
  //}
  //aantalVijand = random(0, 10);
  
  vijand.display(10);
  vijand.move();
  for (var d = 0; d < aantalVijanden; d++){
    if (mario.check2(vijand)){
    //noLoop();
      score = score + 200;
    //vijand.display() = vijand.clear();
    
    //welkScherm=2;
    //console.log("Er is een botsing");
    }
  }
  if (mario.check(vijand)){
    //noLoop();
    welkScherm=2;
  }
    //console.log("Er is een botsing");
}

 

function gameOverScherm() {
  background(220);
  fill(255, 0, 0);
  textSize(32);
  textAlign(CENTER);
  text("Game over", height/3, width/3);
  text("Score: " + score, height/3+30, width/3+30);
}

class Vijand {
  constructor(xPos, yPos, radius, xSpeed){
    this.xPos = xPos;
    this.yPos = yPos;
    this.radius = radius;
    this.xSpeed = xSpeed;
    
  }
  
  display(){
    fill(0, 0, 255);
    this.leftEdgeX = this.xPos - (this.radius+5) - 2*(this.radius-3.5);
    this.upEdgeX = this.yPos - (2*this.radius);
    this.upEdgeX2 = this.yPos + 2*this.radius -12 - 2*(this.radius-3.5);
    this.rightEdgeX = this.xPos + (this.radius+5) - 2*(this.radius-3.5);
    ellipse(this.xPos, this.yPos, 3.75*this.radius, 2*this.radius);
    ellipse(this.xPos - (this.radius+5), this.yPos + 2*this.radius -12, 2*(this.radius-3.5), 2*(this.radius-3.5));
    ellipse(this.xPos + (this.radius+5), this.yPos + 2*this.radius -12, 2*(this.radius-3.5), 2*(this.radius-3.5));
  }
  
  move(){
    //if (this.xPos > width - this.radius || this.xPos < this.radius){
     //     this.xSpeed = -this.xSpeed;
   // }
    this.xPos += -this.xSpeed;
  }
}

class Mario {
  constructor(plHeight, plWidth, radius, xPos, yPos, speed, valSnelheid, zwaartekracht){
    this.plHeight = plHeight;
    this.plWidth = plWidth;
    this.radius = radius;
    this.xPos = xPos;
    this.yPos = yPos;
    this.speed = speed;
    //this.weight = 0.2;
    this.valSnelheid = valSnelheid;
    this.versnelling = zwaartekracht;
  }
  
  display() {
    image(img, this.xPos, this.yPos, this.radius, 2*this.radius);
  }
  
  move() {
    if (this.xPos + this.radius*1.5 > (window.innerWidth)){
        //this.valSnelheid = -2;
        this.xPos = window.innerWidth - this.radius*1.5;
    }

    this.valSnelheid = this.valSnelheid + this.versnelling;
   
    if (this.yPos + this.radius*2 > (window.innerHeight-20)){
        //this.valSnelheid = -2;
        this.yPos = window.innerHeight - 20 - this.radius*2;
        //this.valSnelheid = this.valSnelheid * -1;
        this.valSnelheid = 0;
    }
    
    if (keyIsDown(38)){ //UP_ARROW
      
      this.valSnelheid = -5;
    }

    this.yPos = this.yPos + this.valSnelheid;
    //if (keyIsDown(40)){ //DOWN_ARROW
  //  } 
    if (keyIsDown(37)){ //LEFT_ARROW
      this.xPos -= this.speed;
    }
    if (keyIsDown(39)){ //RIGHT_ARROW
      this.xPos += this.speed;
    }
  }
  check2(vijand){
    if (this.xPos + this.radius - 10 >= vijand.leftEdgeX && 
        // this.yPos <= vijand.upEdgeX2 && 
        this.yPos + this.radius >= vijand.upEdgeX && 
        this.xPos - 25 <= vijand.rightEdgeX){
      console.log("botsing goed");
      return true;
    }
    return false;
  }
  
  check(vijand){
    //zijkanten
    //console.log(this.yPos)
    //console.log(vijand.upEdgeX)
    // if(this.xPos >= vijand.rightEdgeX && this.yPos >= vijand.upEdgeX){
    //   console.log("botsing rechts");
    //   return true;
    // }
    if (this.xPos + this.radius - 5 >= vijand.leftEdgeX && 
         this.yPos + this.radius >= vijand.upEdgeX && 
        this.xPos - 25 <= vijand.rightEdgeX){
      console.log("botsing");
      return true;
      // welkScherm == 2;
    }
    return false;
  }
}

function mousePressed() {
  if (welkScherm==0) {
    startGame();
  }
}

function startGame() {
  welkScherm=1;
}

